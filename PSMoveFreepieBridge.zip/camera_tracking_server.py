import socket
import json
from shutil import copyfile

def update():
		data = {}
		posX = freePieIO[0].x
		posY = freePieIO[0].y
		posZ = freePieIO[0].z

		dicti = {
			"x": str(posX) + "",
			"y": str(posY) + "",
			"z": str(posZ / 100) + ""
		}

		json_object = json.dumps(dicti, indent=4)
		with open("C:\Users\Katana No Tatakai\Documents\sample.json", "w") as outfile:
			outfile.write(json_object)

		try:
			copyfile('C:\Users\Katana No Tatakai\Documents\sample.json', 'C:\Users\Katana No Tatakai\Documents\data.json')
		except:
			diagnostics.debug("Erreur de lecture")
if starting:
	freePieIO[0].update += update